import React from 'react'

export default function EditTopic() {
  return (
    <div className='mx-10'>
        <div className='h-24'></div>
        <div>EditTopic</div>
    </div>
  )
}
